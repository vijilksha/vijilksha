package com.example.feedback.service;

// TODO: Implement FeedbackService class with submitFeedback(), getAllFeedback(), updateFeedback(), deleteFeedback()
