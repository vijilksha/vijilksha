package com.example.feedback.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Feedback {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Employee name must not be blank")
    private String employeeName;

    @NotBlank(message = "Department must not be blank")
    private String department;

    @NotBlank(message = "Feedback message must not be blank")
    private String message;

    // Getters and Setters
    public Long getId() { return id; }
    public String getEmployeeName() { return employeeName; }
    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }
    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
