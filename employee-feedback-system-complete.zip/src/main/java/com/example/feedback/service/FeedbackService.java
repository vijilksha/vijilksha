package com.example.feedback.service;

import com.example.feedback.model.Feedback;
import com.example.feedback.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;

    public Feedback submitFeedback(Feedback feedback) {
        return feedbackRepository.save(feedback);
    }

    public List<Feedback> getAllFeedback() {
        return feedbackRepository.findAll();
    }

    public Feedback updateFeedback(Long id, Feedback updatedFeedback) {
        Optional<Feedback> existing = feedbackRepository.findById(id);
        if (existing.isPresent()) {
            Feedback fb = existing.get();
            fb.setEmployeeName(updatedFeedback.getEmployeeName());
            fb.setDepartment(updatedFeedback.getDepartment());
            fb.setMessage(updatedFeedback.getMessage());
            return feedbackRepository.save(fb);
        } else {
            throw new RuntimeException("Feedback not found with id " + id);
        }
    }

    public void deleteFeedback(Long id) {
        if (!feedbackRepository.existsById(id)) {
            throw new RuntimeException("Feedback not found with id " + id);
        }
        feedbackRepository.deleteById(id);
    }
}
